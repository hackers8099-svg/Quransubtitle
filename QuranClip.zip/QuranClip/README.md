# Quran Clip (Android)

Quran caption video maker: Arabic + translation, presets, custom colors, gradient / image / video background,
MP4 / WebM / transparent WebM / PNG export, automatic ayah sync (Quran.com reciters) or AI sync for your own audio.

## Build the APK with GitHub (no Android Studio)
1. Create a new repository on github.com (e.g. `quran-clip`).
2. Upload ALL files of this zip (after extracting) to the repo root — keep the `.github/workflows/build-apk.yml` path.
3. Open the **Actions** tab -> **Build APK** -> it runs automatically on push (or press *Run workflow*).
4. When it is green (~5-8 min), open the run -> **Artifacts** -> download `QuranClip-APK` -> unzip -> `app-debug.apk`.
5. Copy the APK to your phone and install it (allow "install unknown apps").

## Fonts
Optional KFGQPC fonts: put `KFGQPC_Hafs.ttf`, `KFGQPC_Warsh.ttf`, `KFGQPC_Uthmanic.ttf` in `www/fonts/` before uploading.
You can also add any font file inside the app (Style tab).

## Transparent MOV (ProRes 4444)
The phone exports transparent **WebM (alpha)**. Convert on a PC:
`ffmpeg -c:v libvpx-vp9 -i clip.webm -c:v prores_ks -profile:v 4444 -pix_fmt yuva444p10le clip.mov`

## Notes
- Data: api.quran.com (text, translations, reciters, ayah timings). AI sync: any OpenAI-compatible Whisper endpoint (your own key).
- Video export records in real time. Keep the screen on.
