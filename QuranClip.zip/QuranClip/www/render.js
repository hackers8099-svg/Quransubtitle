const PRESETS = {
  classic: { bgType: 'gradient', c1: '#0a0f1f', c2: '#1b2a4a', angle: 160, arColor: '#ffffff', trColor: '#e6e6e6', accent: '#d4af37', font: 'Amiri Quran', shadow: false },
  emerald: { bgType: 'gradient', c1: '#052e22', c2: '#0b6b4f', angle: 150, arColor: '#ffffff', trColor: '#d7f5e8', accent: '#f5d77a', font: 'Amiri Quran', shadow: false },
  gold:    { bgType: 'solid', c1: '#101010', c2: '#101010', angle: 0, arColor: '#f5d77a', trColor: '#ffffff', accent: '#f5d77a', font: 'Scheherazade New', shadow: false },
  sunset:  { bgType: 'gradient', c1: '#2b1055', c2: '#d8506f', angle: 135, arColor: '#ffffff', trColor: '#ffe9ef', accent: '#ffd166', font: 'Noto Naskh Arabic', shadow: true },
  light:   { bgType: 'solid', c1: '#f7f3ea', c2: '#f7f3ea', angle: 0, arColor: '#1b1b1b', trColor: '#444444', accent: '#8a6d1d', font: 'Amiri', shadow: false },
  overlay: { bgType: 'transparent', c1: '#000000', c2: '#000000', angle: 0, arColor: '#ffffff', trColor: '#ffffff', accent: '#ffffff', font: 'Amiri Quran', shadow: true }
};
const DEFAULT_STYLE = Object.assign({
  trFont: 'Poppins', arSize: 64, trSize: 28, dim: 0.35, ratio: '16:9', res: '720',
  showTr: true, showNum: true, showRef: true, fade: true
}, PRESETS.classic);

const Render = {
  toAr(n) { return String(n).replace(/\d/g, d => '٠١٢٣٤٥٦٧٨٩'[d]); },
  wrap(ctx, text, maxW) {
    const words = text.split(' '), lines = []; let cur = '';
    for (const w of words) {
      const t = cur ? cur + ' ' + w : w;
      if (ctx.measureText(t).width > maxW && cur) { lines.push(cur); cur = w; } else cur = t;
    }
    if (cur) lines.push(cur);
    return lines;
  },
  cover(ctx, src, sw, sh, W, H) {
    if (!sw || !sh) return;
    const s = Math.max(W / sw, H / sh), w = sw * s, h = sh * s;
    ctx.drawImage(src, (W - w) / 2, (H - h) / 2, w, h);
  },
  background(ctx, W, H, S, A) {
    if (S.bgType === 'solid') { ctx.fillStyle = S.c1; ctx.fillRect(0, 0, W, H); }
    else if (S.bgType === 'gradient') {
      const r = S.angle * Math.PI / 180, L = Math.abs(W * Math.sin(r)) + Math.abs(H * Math.cos(r));
      const dx = Math.sin(r) * L / 2, dy = -Math.cos(r) * L / 2;
      const g = ctx.createLinearGradient(W / 2 - dx, H / 2 - dy, W / 2 + dx, H / 2 + dy);
      g.addColorStop(0, S.c1); g.addColorStop(1, S.c2);
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    } else if (S.bgType === 'image' && A.bgImg) {
      Render.cover(ctx, A.bgImg, A.bgImg.naturalWidth, A.bgImg.naturalHeight, W, H);
    } else if (S.bgType === 'video' && A.bgVid) {
      Render.cover(ctx, A.bgVid, A.bgVid.videoWidth, A.bgVid.videoHeight, W, H);
    } else if (S.bgType !== 'transparent') { ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, H); }
    if ((S.bgType === 'image' || S.bgType === 'video') && S.dim > 0) {
      ctx.fillStyle = `rgba(0,0,0,${S.dim})`; ctx.fillRect(0, 0, W, H);
    }
  },
  draw(ctx, W, H, v, alpha, S, A) {
    ctx.clearRect(0, 0, W, H);
    Render.background(ctx, W, H, S, A);
    if (!v) return;
    const k = Math.min(W, H) / 720, maxW = W * 0.86;
    ctx.save();
    ctx.globalAlpha = alpha; ctx.textBaseline = 'middle'; ctx.textAlign = 'center';
    if (S.shadow) { ctx.shadowColor = 'rgba(0,0,0,.75)'; ctx.shadowBlur = 10 * k; ctx.shadowOffsetY = 2 * k; }
    const hasTr = S.showTr && v.tr;
    const arText = v.ar + (S.showNum ? ' \u06DD' + Render.toAr(v.n) : '');
    const famAr = `"${S.font}", "Amiri Quran", serif`;
    let size = S.arSize * k, lines, lh;
    ctx.direction = 'rtl';
    for (let i = 0; i < 16; i++) {
      ctx.font = `${size}px ${famAr}`;
      lines = Render.wrap(ctx, arText, maxW); lh = size * 1.75;
      if (lines.length * lh <= H * (hasTr ? 0.5 : 0.72) || size < 18 * k) break;
      size *= 0.92;
    }
    const arH = lines.length * lh;
    let trLines = [], tsize = S.trSize * k, tlh = 0, trH = 0;
    if (hasTr) {
      ctx.direction = 'ltr';
      for (let i = 0; i < 12; i++) {
        ctx.font = `${tsize}px "${S.trFont}", sans-serif`;
        trLines = Render.wrap(ctx, v.tr, maxW); tlh = tsize * 1.4;
        if (trLines.length * tlh <= H * 0.28 || tsize < 12 * k) break;
        tsize *= 0.92;
      }
      trH = trLines.length * tlh;
    }
    const gap = hasTr ? 22 * k : 0;
    let y = (H - (arH + gap + trH)) / 2;
    ctx.direction = 'rtl'; ctx.font = `${size}px ${famAr}`; ctx.fillStyle = S.arColor;
    lines.forEach((l, i) => ctx.fillText(l, W / 2, y + i * lh + lh / 2));
    y += arH + gap;
    if (hasTr) {
      ctx.direction = 'ltr'; ctx.font = `${tsize}px "${S.trFont}", sans-serif`; ctx.fillStyle = S.trColor;
      trLines.forEach((l, i) => ctx.fillText(l, W / 2, y + i * tlh + tlh / 2));
    }
    if (S.showRef && A.chapterName) {
      ctx.direction = 'ltr'; ctx.font = `600 ${20 * k}px "Poppins", sans-serif`; ctx.fillStyle = S.accent;
      ctx.fillText(`${A.chapterName}  ${v.key}`, W / 2, H - 34 * k);
    }
    ctx.restore();
  }
};
