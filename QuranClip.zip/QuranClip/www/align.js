// AI sync: transcribe audio (Whisper word timestamps) then align words to the Quran text.
function normAr(s) {
  return (s || '')
    .replace(/[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED\u0640\u06DD]/g, '')
    .replace(/[إأآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').replace(/ؤ/g, 'و').replace(/ئ/g, 'ي')
    .replace(/[^\u0621-\u064A ]/g, '').replace(/\s+/g, ' ').trim();
}
function lev(a, b) {
  const m = a.length, n = b.length;
  if (!m) return n; if (!n) return m;
  let prev = Array.from({ length: n + 1 }, (_, i) => i);
  for (let i = 1; i <= m; i++) {
    const cur = [i];
    for (let j = 1; j <= n; j++)
      cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    prev = cur;
  }
  return prev[n];
}
function wsim(a, b) {
  if (a === b) return 1;
  const r = 1 - lev(a, b) / Math.max(a.length, b.length);
  return r >= 0.55 ? r : -0.6;
}
// hyp: [{w,s,e}] (seconds)   ref: [{w,ayah}]   returns array of ayah start/end in ms (length = nAyah)
function alignWords(hyp, ref, nAyah) {
  const n = hyp.length, m = ref.length, W = m + 1, GAP = -0.4;
  if (!n || !m) throw new Error('No words to align');
  const S = new Float32Array((n + 1) * W), T = new Uint8Array((n + 1) * W);
  for (let i = 1; i <= n; i++) { S[i * W] = i * GAP; T[i * W] = 1; }
  for (let j = 1; j <= m; j++) { S[j] = j * GAP; T[j] = 2; }
  for (let i = 1; i <= n; i++) for (let j = 1; j <= m; j++) {
    const d = S[(i - 1) * W + j - 1] + wsim(hyp[i - 1].w, ref[j - 1].w);
    const u = S[(i - 1) * W + j] + GAP, l = S[i * W + j - 1] + GAP;
    let best = d, t = 0;
    if (u > best) { best = u; t = 1; }
    if (l > best) { best = l; t = 2; }
    S[i * W + j] = best; T[i * W + j] = t;
  }
  const map = new Array(m).fill(-1);
  let i = n, j = m;
  while (i > 0 || j > 0) {
    const t = T[i * W + j];
    if (t === 0) { if (wsim(hyp[i - 1].w, ref[j - 1].w) > 0) map[j - 1] = i - 1; i--; j--; }
    else if (t === 1) i--; else j--;
  }
  const start = new Array(nAyah).fill(null), end = new Array(nAyah).fill(null);
  ref.forEach((r, k) => {
    if (map[k] < 0) return;
    const h = hyp[map[k]];
    if (start[r.ayah] === null || h.s < start[r.ayah]) start[r.ayah] = h.s;
    if (end[r.ayah] === null || h.e > end[r.ayah]) end[r.ayah] = h.e;
  });
  // fill gaps + make monotonic
  const total = hyp[n - 1].e;
  let last = 0; const out = [];
  for (let a = 0; a < nAyah; a++) {
    let s = start[a] === null ? last : Math.max(start[a], last);
    out.push(s); last = s;
  }
  out[0] = 0; // first ayah starts at the beginning of the file
  return out.map((s, a) => ({
    from: Math.round(s * 1000),
    to: Math.round((a + 1 < nAyah ? out[a + 1] : Math.max(total, (end[a] ?? total)) + 0.3) * 1000)
  }));
}
async function whisperWords(file, base, key, model) {
  const f = new FormData();
  f.append('file', file); f.append('model', model); f.append('language', 'ar');
  f.append('response_format', 'verbose_json'); f.append('timestamp_granularities[]', 'word');
  const r = await fetch(base + '/audio/transcriptions', { method: 'POST', headers: { Authorization: 'Bearer ' + key }, body: f });
  if (!r.ok) throw new Error('AI error: ' + (await r.text()).slice(0, 200));
  const d = await r.json();
  return (d.words || []).map(x => ({ w: normAr(x.word), s: x.start, e: x.end })).filter(x => x.w);
}
async function aiAlign(file, verses, cfg) {
  const hyp = await whisperWords(file, cfg.base, cfg.key, cfg.model);
  const ref = [];
  verses.forEach((v, a) => normAr(v.ar).split(' ').filter(Boolean).forEach(w => ref.push({ w, ayah: a })));
  return alignWords(hyp, ref, verses.length);
}
if (typeof module !== 'undefined') module.exports = { normAr, alignWords };
