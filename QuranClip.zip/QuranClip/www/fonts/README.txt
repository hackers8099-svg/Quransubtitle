Optional: put KFGQPC fonts here (they are free from the King Fahd Complex site) with EXACT names:
  KFGQPC_Hafs.ttf     (UthmanicHafs)
  KFGQPC_Warsh.ttf    (UthmanicWarsh)
  KFGQPC_Uthmanic.ttf (any other KFGQPC font)
They appear automatically in the Font list. You can also add any .ttf/.otf from inside the app (Style tab).
