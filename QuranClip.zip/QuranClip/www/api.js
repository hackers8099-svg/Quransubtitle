const QF = 'https://api.quran.com/api/v4';
const Api = {
  async j(u) { const r = await fetch(u); if (!r.ok) throw new Error('API ' + r.status + ' ' + u); return r.json(); },
  chapters: () => Api.j(QF + '/chapters?language=en').then(d => d.chapters),
  reciters: () => Api.j(QF + '/resources/chapter_reciters?language=en').then(d => d.reciters),
  translations: () => Api.j(QF + '/resources/translations').then(d => d.translations),
  clean(t) {
    return (t || '').replace(/<sup[^>]*>.*?<\/sup>/gi, '').replace(/<[^>]+>/g, '')
      .replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/\s+/g, ' ').trim();
  },
  async verses(ch, tid) {
    const base = `${QF}/verses/by_chapter/${ch}?language=en&words=false&fields=text_uthmani&per_page=50` + (tid ? `&translations=${tid}` : '');
    const out = []; let page = 1;
    for (;;) {
      const d = await Api.j(base + '&page=' + page);
      out.push(...d.verses);
      if (!d.pagination || !d.pagination.next_page) break;
      page = d.pagination.next_page;
    }
    return out.map(v => ({
      n: v.verse_number, key: v.verse_key, ar: v.text_uthmani,
      tr: v.translations && v.translations[0] ? Api.clean(v.translations[0].text) : ''
    }));
  },
  async timings(reciterId, ch) {
    const d = await Api.j(`${QF}/chapter_recitations/${reciterId}/${ch}?segments=true`);
    const a = d.audio_file;
    let url = a.audio_url;
    if (!/^https?:/.test(url)) url = 'https://download.quranicaudio.com/' + url.replace(/^\//, '');
    const arr = a.timestamps || a.verse_timings || [];
    return {
      url,
      timings: arr.map(t => ({ n: +String(t.verse_key).split(':')[1], from: t.timestamp_from, to: t.timestamp_to }))
    };
  }
};

async function fetchBlob(url) {
  try {
    const r = await fetch(url);
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return await r.blob();
  } catch (e) {
    // fallback: native HTTP (bypasses CORS) when running inside the Android app
    const H = window.Capacitor && Capacitor.Plugins && Capacitor.Plugins.CapacitorHttp;
    if (!H) throw e;
    const r = await H.get({ url, responseType: 'blob' });
    const bin = atob(r.data), u8 = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
    return new Blob([u8], { type: 'audio/mpeg' });
  }
}
