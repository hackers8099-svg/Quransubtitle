(function () {
  const $ = id => document.getElementById(id);
  const cv = $('cv'), ctx = cv.getContext('2d');
  const audio = new Audio(); audio.crossOrigin = 'anonymous'; audio.preload = 'auto';
  let actx, srcNode, spk;
  const st = { chapters: [], reciters: [], tl: [], chapterName: '', upFile: null, bgImg: null, bgVid: null, playing: false, exporting: false, lastTrans: '' };
  const S = Object.assign({}, DEFAULT_STYLE, JSON.parse(localStorage.getItem('qc_style') || '{}'));
  const toast = m => { $('msg').textContent = m; };
  const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
  const fmtT = s => { s = Math.max(0, s | 0); return (s / 60 | 0) + ':' + String(s % 60).padStart(2, '0'); };

  // ---------- tabs ----------
  document.querySelectorAll('nav button').forEach(b => b.onclick = () => {
    document.querySelectorAll('nav button').forEach(x => x.classList.toggle('on', x === b));
    document.querySelectorAll('section').forEach(s => s.classList.toggle('on', s.id === 't-' + b.dataset.t));
  });

  // ---------- fonts ----------
  const FONTS = ['Amiri Quran', 'Amiri', 'Scheherazade New', 'Noto Naskh Arabic', 'Lateef', 'Aref Ruqaa', 'Reem Kufi', 'Noto Kufi Arabic', 'Markazi Text', 'Cairo'];
  function addFontOption(name) {
    const sel = $('font');
    if (![...sel.options].some(o => o.value === name)) sel.add(new Option(name, name));
  }
  async function loadCustomFonts() {
    const files = { 'KFGQPC Hafs': 'KFGQPC_Hafs.ttf', 'KFGQPC Warsh': 'KFGQPC_Warsh.ttf', 'KFGQPC Uthmanic': 'KFGQPC_Uthmanic.ttf' };
    for (const [name, f] of Object.entries(files)) {
      try { const ff = new FontFace(name, `url(fonts/${f})`); await ff.load(); document.fonts.add(ff); addFontOption(name); } catch (e) {}
    }
    $('font').value = S.font;
  }
  $('fontfile').onchange = async e => {
    const f = e.target.files[0]; if (!f) return;
    const name = f.name.replace(/\.[^.]+$/, '');
    const ff = new FontFace(name, await f.arrayBuffer()); await ff.load(); document.fonts.add(ff);
    addFontOption(name); S.font = name; $('font').value = name; redraw(); toast('Font added: ' + name);
  };
  async function ensureFonts() {
    try {
      await Promise.all([`64px "${S.font}"`, `28px "${S.trFont}"`, '20px Poppins'].map(f => document.fonts.load(f, 'السلام Abc')));
    } catch (e) {}
  }

  // ---------- style UI ----------
  function syncStyleUI() {
    document.querySelectorAll('[data-k]').forEach(el => {
      const v = S[el.dataset.k]; if (v === undefined) return;
      if (el.type === 'checkbox') el.checked = !!v; else el.value = v;
    });
  }
  document.querySelectorAll('[data-k]').forEach(el => {
    const h = async () => {
      const k = el.dataset.k;
      S[k] = el.type === 'checkbox' ? el.checked : (el.type === 'range' ? +el.value : el.value);
      localStorage.setItem('qc_style', JSON.stringify(S));
      if (k === 'font' || k === 'trFont') await ensureFonts();
      if (k === 'ratio' || k === 'res') sizeCanvas();
      redraw();
    };
    el.addEventListener('input', h); el.addEventListener('change', h);
  });
  $('preset').onchange = async () => {
    Object.assign(S, PRESETS[$('preset').value]);
    localStorage.setItem('qc_style', JSON.stringify(S));
    syncStyleUI(); await ensureFonts(); redraw();
  };
  $('bgfile').onchange = e => {
    const f = e.target.files[0]; if (!f) return;
    const url = URL.createObjectURL(f);
    if (f.type.startsWith('video')) {
      const v = document.createElement('video'); v.src = url; v.loop = true; v.muted = true; v.playsInline = true;
      v.onloadeddata = () => { st.bgVid = v; S.bgType = 'video'; syncStyleUI(); v.play().catch(() => {}); redraw(); };
    } else {
      const im = new Image(); im.onload = () => { st.bgImg = im; S.bgType = 'image'; syncStyleUI(); redraw(); }; im.src = url;
    }
  };

  // ---------- canvas ----------
  function dims() {
    const [a, b] = S.ratio.split(':').map(Number), sh = +S.res;
    let W, H;
    if (a >= b) { H = sh; W = Math.round(sh * a / b); } else { W = sh; H = Math.round(sh * b / a); }
    return { W: W & ~1, H: H & ~1 };
  }
  function sizeCanvas() { const { W, H } = dims(); cv.width = W; cv.height = H; }
  function assets() { return { bgImg: st.bgImg, bgVid: st.bgVid, chapterName: st.chapterName }; }
  function curVerse(tMs) {
    if (!st.tl.length) return null;
    let v = st.tl[0];
    for (const x of st.tl) if (x.from <= tMs) v = x;
    return v;
  }
  function range() { return st.tl.length ? [st.tl[0].from / 1000, st.tl[st.tl.length - 1].to / 1000] : [0, 0]; }
  function redraw() {
    if (st.playing) return;
    const t = audio.currentTime * 1000, v = curVerse(t);
    Render.draw(ctx, cv.width, cv.height, v, 1, S, assets());
  }
  function frame() {
    const t = audio.currentTime * 1000, v = curVerse(t);
    const a = S.fade && v ? clamp((t - v.from) / 350, 0, 1) : 1;
    Render.draw(ctx, cv.width, cv.height, v, a, S, assets());
    const [s, e] = range();
    $('seek').value = Math.max(0, audio.currentTime - s);
    $('time').textContent = fmtT(audio.currentTime - s) + ' / ' + fmtT(e - s);
  }

  // ---------- playback ----------
  function ensureAudioCtx() {
    if (actx) return;
    actx = new (window.AudioContext || window.webkitAudioContext)();
    srcNode = actx.createMediaElementSource(audio);
    spk = actx.createGain(); srcNode.connect(spk); spk.connect(actx.destination);
  }
  function loop() {
    if (!st.playing) return;
    const [s, e] = range();
    frame();
    if (audio.currentTime >= e && !st.exporting) { pause(); audio.currentTime = s; redraw(); return; }
    requestAnimationFrame(loop);
  }
  async function play() {
    if (!st.tl.length) return toast('Load first.');
    ensureAudioCtx(); await actx.resume();
    const [s, e] = range();
    if (audio.currentTime < s || audio.currentTime >= e - 0.05) audio.currentTime = s;
    if (st.bgVid) st.bgVid.play().catch(() => {});
    await audio.play(); st.playing = true; $('play').textContent = '⏸'; loop();
  }
  function pause() { audio.pause(); st.playing = false; $('play').textContent = '▶'; }
  $('play').onclick = () => st.playing ? pause() : play();
  $('seek').oninput = () => { audio.currentTime = range()[0] + +$('seek').value; if (!st.playing) { redraw(); frame(); } };
  function setupSeek() {
    const [s, e] = range();
    $('seek').max = Math.max(0.1, e - s); audio.currentTime = s; sizeCanvas();
    $('time').textContent = '0:00 / ' + fmtT(e - s); redraw();
  }

  // ---------- data ----------
  function fillRecitersList() {
    const re = $('riwaya').value ? new RegExp($('riwaya').value, 'i') : null;
    const sel = $('reciter'); sel.innerHTML = '';
    st.reciters.forEach(r => {
      const label = r.name + (r.qirat && r.qirat.name ? ' – ' + r.qirat.name : '') + (r.style && r.style.name ? ' (' + r.style.name + ')' : '');
      if (re && !re.test(label + ' ' + (r.arabic_name || ''))) return;
      sel.add(new Option(label, r.id));
    });
    if (!sel.options.length) sel.add(new Option('No reciter matches this filter', ''));
  }
  $('riwaya').onchange = fillRecitersList;
  $('mode').onchange = () => {
    const q = $('mode').value === 'quran';
    $('m-quran').style.display = q ? 'flex' : 'none';
    $('m-upload').style.display = q ? 'none' : 'flex';
  };
  $('surah').onchange = () => {
    const c = st.chapters.find(x => x.id == $('surah').value);
    $('from').value = 1; $('to').value = c.verses_count; $('to').max = c.verses_count;
  };
  $('upfile').onchange = e => { st.upFile = e.target.files[0] || null; };

  async function init() {
    syncStyleUI();
    FONTS.forEach(addFontOption); $('font').value = S.font;
    ['aiBase', 'aiKey', 'aiModel'].forEach(id => { const v = localStorage.getItem('qc_' + id); if (v) $(id).value = v; $(id).onchange = () => localStorage.setItem('qc_' + id, $(id).value); });
    sizeCanvas(); loadCustomFonts().then(ensureFonts).then(redraw);
    try {
      st.chapters = await Api.chapters();
      st.chapters.forEach(c => $('surah').add(new Option(`${c.id}. ${c.name_simple} (${c.verses_count})`, c.id)));
      $('surah').value = 1; $('surah').onchange();
      Api.reciters().then(r => { st.reciters = r; fillRecitersList(); }).catch(e => toast('Reciters: ' + e.message));
      Api.translations().then(list => {
        const groups = {};
        list.forEach(t => (groups[t.language_name] = groups[t.language_name] || []).push(t));
        Object.keys(groups).sort().forEach(l => {
          const og = document.createElement('optgroup'); og.label = l;
          groups[l].forEach(t => og.appendChild(new Option(t.name + (t.author_name ? ' – ' + t.author_name : ''), t.id)));
          $('trans').appendChild(og);
        });
        const en = list.find(t => t.id === 131); if (en) $('trans').value = 131;
      }).catch(e => toast('Translations: ' + e.message));
      toast('Ready. Choose surah / reciter, then Load.');
    } catch (e) { toast('Could not reach Quran API – check internet.\n' + e.message); }
  }

  async function setAudioBlob(url) {
    toast('Downloading audio…');
    const blob = await fetchBlob(url);
    if (audio.dataset.obj) URL.revokeObjectURL(audio.dataset.obj);
    const o = URL.createObjectURL(blob); audio.dataset.obj = o; audio.src = o;
    await new Promise((res, rej) => { audio.onloadedmetadata = res; audio.onerror = () => rej(new Error('Audio failed to load')); });
  }

  $('load').onclick = async () => {
    try {
      pause();
      const ch = +$('surah').value, a = +$('from').value, b = +$('to').value;
      if (a > b) throw new Error('From must be ≤ To');
      st.chapterName = st.chapters.find(c => c.id === ch).name_simple;
      await ensureFonts();
      toast('Loading ayahs…');
      const verses = (await Api.verses(ch, $('trans').value)).filter(v => v.n >= a && v.n <= b);
      if ($('mode').value === 'quran') {
        const rid = $('reciter').value; if (!rid) throw new Error('Choose a reciter');
        const d = await Api.timings(rid, ch);
        const map = {}; d.timings.forEach(t => map[t.n] = t);
        st.tl = verses.filter(v => map[v.n]).map(v => ({ ...v, from: map[v.n].from, to: map[v.n].to }));
        if (!st.tl.length) throw new Error('No timing data for this reciter/surah');
        await setAudioBlob(d.url);
      } else {
        if (!st.upFile) throw new Error('Choose an audio file first');
        if (audio.dataset.obj) URL.revokeObjectURL(audio.dataset.obj);
        const o = URL.createObjectURL(st.upFile); audio.dataset.obj = o; audio.src = o;
        await new Promise((res, rej) => { audio.onloadedmetadata = res; audio.onerror = () => rej(new Error('Audio failed to load')); });
        const dur = audio.duration * 1000, n = verses.length;
        st.tl = verses.map((v, i) => ({ ...v, from: dur * i / n, to: dur * (i + 1) / n })); // rough placeholder until synced
        toast('Loaded. Now run AI auto-sync or Tap sync (timings are placeholders).');
        setupSeek(); return;
      }
      toast(`Loaded ${st.tl.length} ayahs. Press ▶`);
      setupSeek();
    } catch (e) { toast('Error: ' + e.message); }
  };

  // ---------- sync (upload mode) ----------
  $('aiSync').onclick = async () => {
    try {
      if (!st.tl.length || !st.upFile) throw new Error('Load your audio first');
      const key = $('aiKey').value.trim(); if (!key) throw new Error('Enter API key');
      toast('Transcribing with AI… (file must be < 25 MB)');
      const res = await aiAlign(st.upFile, st.tl, { base: $('aiBase').value, key, model: $('aiModel').value });
      st.tl.forEach((v, i) => { v.from = res[i].from; v.to = res[i].to; });
      setupSeek(); toast('AI sync done. Press ▶ to check; fix with Tap sync if needed.');
    } catch (e) { toast('Error: ' + e.message); }
  };
  $('aiBase').addEventListener('change', () => { $('aiModel').value = $('aiBase').value.includes('groq') ? 'whisper-large-v3' : 'whisper-1'; });

  let tapIdx = -1;
  $('tapSync').onclick = async () => {
    if (!st.tl.length || !st.upFile) return toast('Load your audio first');
    tapIdx = 0; audio.currentTime = 0; ensureAudioCtx(); await actx.resume(); await audio.play();
    $('tap').style.display = 'block'; $('tap').textContent = 'TAP when ayah ' + st.tl[0].n + ' starts';
  };
  $('tap').onclick = () => {
    if (tapIdx < 0) return;
    st.tl[tapIdx].from = tapIdx === 0 ? 0 : audio.currentTime * 1000;
    Render.draw(ctx, cv.width, cv.height, st.tl[tapIdx], 1, S, assets());
    tapIdx++;
    if (tapIdx >= st.tl.length) {
      audio.pause(); $('tap').style.display = 'none'; tapIdx = -1;
      st.tl.forEach((v, i) => v.to = i + 1 < st.tl.length ? st.tl[i + 1].from : audio.duration * 1000);
      setupSeek(); toast('Tap sync saved. Press ▶');
    } else $('tap').textContent = 'TAP when ayah ' + st.tl[tapIdx].n + ' starts';
  };

  // ---------- export ----------
  function b64(blob) {
    return new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result).split(',')[1]); r.onerror = rej; r.readAsDataURL(blob); });
  }
  async function saveBlob(blob, name, share = true) {
    const P = window.Capacitor && Capacitor.Plugins;
    if (!P || !P.Filesystem) { const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; a.click(); return; }
    const data = await b64(blob); let uri;
    try {
      try { await P.Filesystem.requestPermissions(); } catch (e) {}
      uri = (await P.Filesystem.writeFile({ path: 'QuranClip/' + name, data, directory: 'DOCUMENTS', recursive: true })).uri;
      toast('Saved: Documents/QuranClip/' + name);
    } catch (e) {
      uri = (await P.Filesystem.writeFile({ path: name, data, directory: 'CACHE' })).uri;
    }
    if (share && P.Share) { try { await P.Share.share({ title: name, url: uri }); } catch (e) {} }
  }
  const baseName = () => `${st.chapterName.replace(/\W+/g, '_')}_${st.tl[0].n}-${st.tl[st.tl.length - 1].n}`;

  async function exportPNG(all) {
    const { W, H } = dims(); const c = document.createElement('canvas'); c.width = W; c.height = H; const x = c.getContext('2d');
    const list = all ? st.tl : [curVerse(audio.currentTime * 1000)];
    for (const v of list) {
      Render.draw(x, W, H, v, 1, S, assets());
      const blob = await new Promise(r => c.toBlob(r, 'image/png'));
      toast('Saving ayah ' + v.n + '…');
      await saveBlob(blob, `${st.chapterName.replace(/\W+/g, '_')}_${v.n}.png`, !all);
    }
    toast('PNG export done.');
  }

  async function exportVideo(kind) {
    pause();
    const { W, H } = dims(); cv.width = W; cv.height = H;
    const alpha = kind === 'alpha';
    const tries = kind === 'mp4'
      ? ['video/mp4;codecs=avc1.42E01E,mp4a.40.2', 'video/mp4', 'video/webm;codecs=vp9,opus', 'video/webm']
      : alpha ? ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm']
              : ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm'];
    const mime = tries.find(m => window.MediaRecorder && MediaRecorder.isTypeSupported(m));
    if (!mime) throw new Error('This device cannot record video');
    if (kind === 'mp4' && !mime.startsWith('video/mp4')) toast('MP4 not supported here – exporting WebM instead.');
    if (alpha) { S.bgType = 'transparent'; syncStyleUI(); }
    ensureAudioCtx(); await actx.resume();
    const dest = actx.createMediaStreamDestination(); srcNode.connect(dest); spk.gain.value = 0;
    const stream = cv.captureStream(30);
    dest.stream.getAudioTracks().forEach(t => stream.addTrack(t));
    const rec = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: W >= 1080 ? 10e6 : 6e6, audioBitsPerSecond: 160000 });
    const chunks = []; rec.ondataavailable = e => e.data.size && chunks.push(e.data);
    const [s, e] = range();
    audio.currentTime = s; if (st.bgVid) { st.bgVid.currentTime = 0; st.bgVid.play().catch(() => {}); }
    st.exporting = true; st.playing = true;
    rec.start(500); await audio.play();
    await new Promise(res => {
      const step = () => {
        frame(); const p = (audio.currentTime - s) / (e - s);
        toast('Recording… ' + Math.round(clamp(p, 0, 1) * 100) + '%');
        if (audio.currentTime >= e || audio.ended) return res(); requestAnimationFrame(step);
      }; step();
    });
    await new Promise(r => setTimeout(r, 300));
    audio.pause(); rec.stop(); await new Promise(r => rec.onstop = r);
    st.exporting = false; st.playing = false; spk.gain.value = 1; srcNode.disconnect(dest); $('play').textContent = '▶';
    const ext = mime.startsWith('video/mp4') ? 'mp4' : 'webm';
    const blob = new Blob(chunks, { type: mime.split(';')[0] });
    await saveBlob(blob, `${baseName()}${alpha ? '_alpha' : ''}.${ext}`);
    toast('Done: ' + baseName() + '.' + ext);
  }

  $('export').onclick = async () => {
    try {
      if (!st.tl.length) throw new Error('Load first');
      await ensureFonts();
      const f = $('fmt').value;
      if (f === 'png') await exportPNG(false); else if (f === 'pngall') await exportPNG(true); else await exportVideo(f);
    } catch (e) { st.exporting = false; st.playing = false; toast('Error: ' + e.message); }
  };

  init();
})();
